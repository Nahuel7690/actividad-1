function ocultarDiv() {
    var div2 = document.getElementById("div2");
     
    var parrafosDiv2 = div2.getElementsByTagName("p");
    
    for (var i = 0; i < parrafosDiv2.length; i++) {
        parrafosDiv2[i].style.display = "none";
    }
}