function definirAtributo() {
    var tabla = document.getElementById("tabla1");

    tabla.style.border = "5px solid black";
}