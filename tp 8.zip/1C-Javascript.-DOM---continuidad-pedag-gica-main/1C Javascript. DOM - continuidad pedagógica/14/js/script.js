function insertarParrafo() {
    var contenedor = document.getElementById("contenedor");
    var nuevoParrafo = document.createElement("p");
    var texto = document.createTextNode("Nuevo parrafo");
    nuevoParrafo.appendChild(texto);
    contenedor.insertBefore(nuevoParrafo, contenedor.firstChild);
}