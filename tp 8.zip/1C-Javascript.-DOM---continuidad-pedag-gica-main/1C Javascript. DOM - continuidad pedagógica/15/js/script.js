function borrarParrafo() {
    var posicionInput = document.getElementById("posicion").value;
    var contenedor = document.getElementById("contenedor");

    var posicion = parseInt(posicionInput);

    if (posicion >= 0 && posicion <= 2) {
        var parrafoBorrar = contenedor.getElementsByTagName("p")[posicion];
        
        if (parrafoBorrar) {
            parrafoBorrar.remove();
        } else {
            alert("No hay un párrafo en la posición especificada.");
        }
    } else {
        alert("La posición debe ser un número entre 0 y 2.");
    }
}