var div = document.getElementById("div");

var ultimoHijo = div.lastElementChild;

alert(ultimoHijo.textContent);
ultimoHijo = ultimoHijo.previousElementSibling;