function cambiarTamFuente(tam) {
    var mensaje = document.getElementById("mensaje");
    mensaje.style.fontSize = tam + "px";
}