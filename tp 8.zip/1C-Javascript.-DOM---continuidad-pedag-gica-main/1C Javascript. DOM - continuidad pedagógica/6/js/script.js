function cambiarTamFuente() {
    let puntero = document.getElementById('parrafo1')
    let padre = puntero.parentNode
    padre.style.fontSize = '40px'
}