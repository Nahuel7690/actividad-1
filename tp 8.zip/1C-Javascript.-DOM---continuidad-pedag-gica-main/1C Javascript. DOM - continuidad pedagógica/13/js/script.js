var contador = 0;

function agregarMarca() {
    if (contador < 1) {
        var lista = document.getElementById("lista");
        
        var marca1 = document.createElement("li");
        marca1.textContent = "Elemento 1";
        lista.appendChild(marca1);
        
        var marca2 = document.createElement("li");
        marca2.textContent = "Elemento 2";
        lista.appendChild(marca2);
        
        contador++;
        
        if (contador >= 1) {
            var boton = document.querySelector("button");
            boton.disabled = true;
        }
    }
}