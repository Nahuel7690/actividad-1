function agregarTexto() {
    var marcasLista = document.getElementById("lista").getElementsByTagName("li");
    
    for (var i = 0; i < marcasLista.length; i++) {
        marcasLista[i].textContent = "Elemento " + (i + 1); 
    }
}
