var contador = 0;
function agregarNodoTexto() {
    contador++;
    var parrafo = document.getElementById("parrafo");
    var nuevoNodoTexto = document.createTextNode("Nodo de texto " + contador);
    parrafo.appendChild(nuevoNodoTexto);
}

function eliminarNodoTexto() {
    var parrafo = document.getElementById("parrafo");
    if (parrafo.hasChildNodes()) {
        parrafo.removeChild(parrafo.firstChild);
        contador--;
    }
}