function contarNodos() {
    var div1 = document.getElementById("div1");
    var div2 = document.getElementById("div2");

    var numNodosDiv1 = div1.childNodes.length;
    var numNodosDiv2 = div2.childNodes.length;

    alert("Cantidad de nodos hijos en el primer div: " + numNodosDiv1 + "\nCantidad de nodos hijos en el segundo div: " + numNodosDiv2);
}

function contarElementos() {
    var div1 = document.getElementById("div1");
    var div2 = document.getElementById("div2");

    var numElementosDiv1 = div1.children.length;
    var numElementosDiv2 = div2.children.length;

    alert("Cantidad de elementos en el primer div: " + numElementosDiv1 + "\nCantidad de elementos en el segundo div: " + numElementosDiv2);
}