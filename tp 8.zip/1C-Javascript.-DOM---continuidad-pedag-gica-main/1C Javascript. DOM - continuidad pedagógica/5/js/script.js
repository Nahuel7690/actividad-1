var contadorElemento = document.getElementById("contador");

var valorTexto = contadorElemento.firstChild.nodeValue;

var nuevoValor = parseInt(valorTexto) + 1;

contadorElemento.firstChild.nodeValue = nuevoValor;