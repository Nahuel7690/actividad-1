var primeraFila = document.getElementById("tabla").rows[0];

for (var i = 0; i < primeraFila.cells.length; i++) {
    var textoCelda = primeraFila.cells[i].textContent;
    alert("Texto de la celda " + (i+1) + ": " + textoCelda);
}